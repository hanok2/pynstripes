
class GlobalValues:
    def __init__(self) -> None:
        self.screen_width = 80
        self.screen_height= 50
        self.room_max_size = 10
        self.room_min_size = 6
        self.max_rooms = 30
        self.max_monsters_per_room = 2

globals = GlobalValues()
